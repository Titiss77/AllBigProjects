-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Hôte : sql307.byethost7.com
-- Généré le :  mer. 16 sep. 2026 à 17:28
-- Version du serveur :  11.4.13-MariaDB
-- Version de PHP :  7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `b7_41910034_intranap_club`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `nom_categorie` varchar(20) NOT NULL,
  `libelle` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`id`, `nom_categorie`, `libelle`) VALUES
(1, 'F45+', 'Masters F45+'),
(2, 'FCA', 'Cadettes'),
(3, 'FSE', 'Seniors F'),
(6, 'FMI', 'Minimes F'),
(10, 'F35+', 'Masters F35+'),
(11, 'FJU', 'Juniors F'),
(13, 'HSE', 'Seniors H'),
(15, 'HJU', 'Juniors H'),
(16, 'HCA', 'Cadets'),
(18, 'H45+', 'Masters H45+'),
(21, 'HMI', 'Minimes H'),
(22, 'HBE', 'Benjamins'),
(31, 'F55+', 'Masters F55+'),
(47, 'H55+', 'Masters H55+'),
(49, 'H35+', 'Masters H35+'),
(290, 'FBE', 'Benjamines'),
(398, 'FPO', 'Poussines'),
(2265, 'HPO', 'Poussins'),
(2420, '', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `epreuves`
--

CREATE TABLE `epreuves` (
  `id` int(11) NOT NULL,
  `nom_epreuve` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `epreuves`
--

INSERT INTO `epreuves` (`id`, `nom_epreuve`) VALUES
(15, '100BI'),
(10, '100IS'),
(4, '100SF'),
(8, '1500SF'),
(16, '200BI'),
(12, '200IS'),
(5, '200SF'),
(17, '400BI'),
(13, '400IS'),
(6, '400SF'),
(18, '4x100BI'),
(9, '50AP'),
(14, '50BI'),
(1, '50SF'),
(11, '800IS'),
(7, '800SF');

-- --------------------------------------------------------

--
-- Structure de la table `grille_qualifs`
--

CREATE TABLE `grille_qualifs` (
  `id` int(11) NOT NULL,
  `epreuve_id` int(11) NOT NULL,
  `categorie_id` int(11) NOT NULL,
  `temps_de_ref` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `grille_qualifs`
--

INSERT INTO `grille_qualifs` (`id`, `epreuve_id`, `categorie_id`, `temps_de_ref`) VALUES
(1, 1, 3, '00:21.75'),
(2, 4, 3, '00:48.90'),
(3, 5, 3, '01:50.00'),
(4, 6, 3, '04:02.00'),
(5, 7, 3, '08:33.00'),
(6, 8, 3, '18:00.00'),
(7, 9, 3, '00:20.75'),
(8, 10, 3, '00:48.40'),
(9, 12, 3, '01:49.00'),
(10, 13, 3, '04:40.00'),
(11, 14, 3, '00:25.50'),
(12, 15, 3, '00:55.80'),
(13, 16, 3, '02:03.00'),
(14, 17, 3, '04:30.00'),
(15, 1, 13, '00:19.25'),
(16, 4, 13, '00:42.60'),
(17, 5, 13, '01:40.00'),
(18, 6, 13, '03:37.00'),
(19, 7, 13, '07:47.00'),
(20, 8, 13, '17:00.00'),
(21, 9, 13, '00:18.25'),
(22, 10, 13, '00:42.10'),
(23, 12, 13, '01:39.00'),
(24, 13, 13, '04:15.00'),
(25, 14, 13, '00:22.20'),
(26, 15, 13, '00:50.00'),
(27, 16, 13, '01:51.00'),
(28, 17, 13, '04:00.00'),
(29, 1, 11, '00:23.75'),
(30, 4, 11, '00:52.50'),
(31, 5, 11, '01:57.00'),
(32, 6, 11, '04:14.00'),
(33, 7, 11, '08:54.00'),
(34, 8, 11, '18:30.00'),
(35, 9, 11, '00:22.75'),
(36, 10, 11, '00:52.00'),
(37, 12, 11, '01:55.00'),
(38, 13, 11, '04:50.00'),
(39, 14, 11, '00:27.00'),
(40, 15, 11, '00:58.00'),
(41, 16, 11, '02:12.00'),
(42, 17, 11, '04:50.00'),
(43, 1, 15, '00:21.75'),
(44, 4, 15, '00:47.00'),
(45, 5, 15, '01:47.00'),
(46, 6, 15, '03:54.00'),
(47, 7, 15, '08:04.00'),
(48, 8, 15, '17:30.00'),
(49, 9, 15, '00:20.75'),
(50, 10, 15, '00:46.50'),
(51, 12, 15, '01:45.00'),
(52, 13, 15, '04:35.00'),
(53, 14, 15, '00:23.50'),
(54, 15, 15, '00:52.00'),
(55, 16, 15, '01:56.00'),
(56, 17, 15, '04:20.00');

-- --------------------------------------------------------

--
-- Structure de la table `lieux`
--

CREATE TABLE `lieux` (
  `id` int(11) NOT NULL,
  `nom_lieu` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `lieux`
--

INSERT INTO `lieux` (`id`, `nom_lieu`) VALUES
(1777, 'Abbeville (80 somme)'),
(1033, 'Aix en provence'),
(1338, 'Aix en provence (13 bouches du rhone)'),
(1487, 'Aix-en-provence'),
(2531, 'Amnéville'),
(12, 'Angers '),
(22, 'Auray'),
(33, 'Baud'),
(264, 'Brest'),
(1, 'Brest, piscine de recouvrance '),
(2532, 'Chartres'),
(1794, 'Chartres (28) centre aquatique'),
(967, 'Chateaubriant'),
(385, 'Dijon'),
(1183, 'Herouville'),
(1827, 'hongrie '),
(2076, 'La roche sur yon'),
(2256, 'La roche/yon'),
(92, 'Limoges'),
(2, 'Lorient '),
(2073, 'Montluçon'),
(1810, 'Montlucon (03) '),
(1809, 'Montlucon (03) centre aqua. de la loue'),
(2035, 'Montluçon (03-allier)'),
(2090, 'Montpellier'),
(2239, 'Pierrelatte (drôme)'),
(2549, 'Poznan'),
(279, 'Quimper'),
(2020, 'Quimper (29)'),
(261, 'Rennes'),
(1337, 'Rennes (35 ille-et-vilaine)'),
(3, 'Rennes (35) - piscine de brequigny'),
(1486, 'Rennes - piscine de bréquigny'),
(1485, 'Rennes-piscine de bréquigny'),
(1414, 'Romans sur isere'),
(1021, 'Saint-malo'),
(2501, 'Tours '),
(1554, 'Valence (26 drôme)'),
(11, 'Vannes'),
(1157, 'Versailles'),
(6, 'Versailles (78)'),
(1581, 'Versailles (78) confirmé'),
(1165, 'Villenave d\'ornon'),
(1259, 'Vittel');

-- --------------------------------------------------------

--
-- Structure de la table `nageurs`
--

CREATE TABLE `nageurs` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `genre` varchar(10) NOT NULL,
  `date_naissance` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `nageurs`
--

INSERT INTO `nageurs` (`id`, `nom`, `prenom`, `genre`, `date_naissance`) VALUES
(1, 'GOBIN', 'Tifenn', 'Femmes', '1980-04-01'),
(2, 'KERJEAN', 'Eloise', 'Femmes', '2010-01-31'),
(3, 'NAVARRETE', 'Tesa', 'Femmes', '2007-05-26'),
(4, 'TANGUY', 'Chloe', 'Femmes', '2002-04-23'),
(5, 'BARBOT', 'Erell', 'Femmes', '2007-02-11'),
(6, 'RIOU', 'Julia', 'Femmes', '2013-01-19'),
(7, 'ROZE', 'Emma', 'Femmes', '2011-11-19'),
(8, 'LEBEE', 'Garance', 'Femmes', '2012-07-28'),
(9, 'VIGOUROUX', 'Nina', 'Femmes', '2013-10-08'),
(10, 'MARTIN', 'Céline', 'Femmes', '1985-01-09'),
(11, 'PENNARUN', 'Lea', 'Femmes', '2009-10-29'),
(12, 'LAVIGNE ', 'Anne', 'Femmes', '1981-10-06'),
(13, 'FRANCES', 'Mathis', 'Hommes', '2006-07-02'),
(14, 'GLEDEL-LESCARRET', 'Lorys', 'Hommes', '2006-08-26'),
(15, 'LEDUC', 'Zacharie', 'Hommes', '2009-04-07'),
(16, 'SOLLAZZO', 'Luca', 'Hommes', '2011-06-18'),
(17, 'SEGALEN', 'Nore', 'Hommes', '2009-09-13'),
(18, 'PRIGENT', 'Yves', 'Hommes', '1978-06-03'),
(19, 'VIGOUROUX', 'Nevis', 'Hommes', '2011-05-25'),
(20, 'PRIGENT', 'Celian', 'Hommes', '2010-12-18'),
(21, 'LE POGAM', 'Maxime', 'Hommes', '2012-01-25'),
(22, 'LANDOLSI', 'Simon', 'Hommes', '2014-02-25'),
(23, 'MAZOUZ PEILLET', 'Rayan', 'Hommes', '2011-12-08'),
(24, 'LESPAGNOL', 'Domitile', 'Femmes', '2006-09-16'),
(25, 'LE BIGOT ', 'Maelys', 'Femmes', '2008-06-10'),
(26, 'LECLERC', 'Anna', 'Femmes', '2007-10-04'),
(27, 'FEAT', 'Anne', 'Femmes', '1968-11-09'),
(28, 'FRINAULT', 'Anne', 'Femmes', '1966-05-25'),
(29, 'LE COANT ', 'Marie', 'Femmes', '1975-07-29'),
(30, 'HENRI', 'Thierry', 'Hommes', '1962-12-24'),
(31, 'SANCEAU', 'Matthieu', 'Hommes', '1990-11-05'),
(32, 'KERJEAN', 'Christophe', 'Hommes', '1975-08-21'),
(33, 'GUILLOU', 'Gilles', 'Hommes', '1971-07-05'),
(34, 'MOAL', 'Sabine', 'Femmes', '1970-12-11'),
(35, 'LANDOLSI', 'Marie', 'Femmes', '1978-05-15'),
(36, 'BOUTOUILLER', 'Florie', 'Femmes', '2005-06-14'),
(37, 'LEDUC', 'Emma', 'Femmes', '2004-05-08'),
(38, 'KERGOURLAY', 'Sandra', 'Femmes', '1973-10-14'),
(39, 'CHARPENTIER', 'Samuel', 'Hommes', '2009-09-18'),
(40, 'ROISEUX', 'Manny', 'Hommes', '2008-04-13'),
(41, 'OLLIVIER', 'Gérard', 'Hommes', '1969-04-19'),
(42, 'MAO', 'Joseph', 'Hommes', '1949-04-02'),
(43, 'CAMUS', 'Pauline', 'Femmes', '2009-03-31'),
(44, 'LEBEE', 'Thomas', 'Hommes', '1979-09-11'),
(45, 'SOLLAZZO', 'Gabriele', 'Hommes', '2016-01-15'),
(46, 'STEPHAN', 'Elodie', 'Femmes', '1993-10-20'),
(47, 'COATHALEM', 'Lou', 'Femmes', '2015-01-21'),
(48, 'LE TREUT', 'Emy', 'Femmes', '2014-05-24'),
(49, 'CARRENO NICOLAS', 'Celia', 'Femmes', '2015-03-09'),
(50, 'TORC\'H', 'Killian', 'Hommes', '2003-08-13'),
(51, 'LE TREUT', 'Julie', 'Femmes', '1989-04-07'),
(52, 'LE GALL', 'Helene', 'Femmes', '1982-11-25'),
(53, 'LE TREUT', 'Maë', 'Femmes', '2017-04-01'),
(54, 'SOLLAZZO', 'Azzura', 'Femmes', '2017-12-14'),
(55, 'PRIGENT', 'Sandra', 'Femmes', '1973-04-26'),
(56, 'LEGRAND', 'Titouan', 'Hommes', '2012-09-06'),
(57, 'LACO', 'Jeanne', 'Femmes', '2007-09-27'),
(58, 'QUERE', 'Lou-anne', 'Femmes', '2010-05-25'),
(59, 'KERJEAN', 'Maxim', 'Hommes', '2005-01-04'),
(60, 'LE NOC', 'Mathis', 'Hommes', '2006-06-05'),
(61, 'LE GALL', 'Thomas', 'Hommes', '2003-02-18'),
(62, 'KYLLIAN', 'Quere', 'Hommes', '2006-04-28'),
(63, 'DORMEGNIES', 'Mayeul', 'Hommes', '2010-04-22'),
(64, 'QUERE', 'Timéo', 'Hommes', '2008-12-24'),
(65, 'LE BOURGOCQ', 'Daphne', 'Femmes', '2008-03-27'),
(66, 'MORVAN', 'Mona', 'Femmes', '2007-12-29'),
(67, 'TEZENAS', 'Constance', 'Femmes', '2006-01-18'),
(68, 'PORCHERON', 'Alwena', 'Femmes', '2005-04-23'),
(69, 'RENEVOT', 'Chloe', 'Femmes', '2005-08-21'),
(70, 'SILCHER', 'Leanore', 'Femmes', '2006-03-21'),
(71, 'LE GOFF', 'Lea', 'Femmes', '2009-06-28'),
(72, 'LAVIGNE', 'Lise', 'Femmes', '2009-08-06'),
(73, 'LESPAGNOL', 'Martin', 'Hommes', '2002-03-19'),
(74, 'DIRUIT ', 'Thomas', 'Hommes', '1996-07-08'),
(75, 'MICOUT', 'Christophe', 'Hommes', '2005-06-28'),
(76, 'BIRD', 'Morgan', 'Hommes', '2001-09-10'),
(77, 'SICHLER', 'Marianne', 'Femmes', '1970-09-15'),
(78, 'LESPAGNOL', 'Rodolphe', 'Hommes', '1970-03-24'),
(79, 'BIRD', 'Clarence', 'Femmes', '2005-10-15'),
(80, 'POTIN', 'Jade', 'Femmes', '2003-04-06'),
(81, 'STEPHAN', 'Clemence', 'Femmes', '2009-07-21'),
(82, 'PRINGENT', 'Yves', 'Hommes', '1978-06-03'),
(83, 'MAURER', 'Irine', 'Femmes', '2004-03-06'),
(84, 'PLOUHINEC ', 'Malo', 'Hommes', '2003-09-23'),
(85, 'DIDOU', 'Alexandre', 'Hommes', '2007-08-18'),
(86, 'OLIVIER ', 'Romane', 'Femmes', '2007-12-26'),
(87, 'SEZNEC', 'Louis maël', 'Hommes', '2003-02-11'),
(88, 'POULIQUEN', 'Adelie', 'Femmes', '2002-05-25'),
(89, 'DIDOU', 'Caroline', 'Femmes', '2002-05-13'),
(90, 'MAURER', 'Evane', 'Femmes', '1998-04-12'),
(91, 'KERNALEGUEN', 'Manon', 'Femmes', '1998-08-25'),
(92, 'LE BIHAN', 'Aude', 'Femmes', '1987-11-25'),
(93, 'POTIN', 'Eden', 'Femmes', '2005-11-16'),
(94, 'LE GOUES', 'Melenn', 'Femmes', '2003-07-02'),
(95, 'LE CLEAC-H', 'Euriel', 'Femmes', '2004-08-04'),
(96, 'LE CLEAC\'H', 'Euriel', 'Femmes', '2004-08-04'),
(97, 'PENOBERT', 'Gabrielle', 'Femmes', '2004-12-26'),
(98, 'COROLLER', 'Gwenn', 'Femmes', '2005-03-18'),
(99, 'GLEDEL-LESCARRET', 'Estephe', 'Hommes', '2004-12-12'),
(100, 'BIHAN-POUDEC', 'Tanguy', 'Hommes', '2002-10-19'),
(101, 'RENEVOT', 'Baptiste', 'Hommes', '2000-02-27'),
(102, 'KERNALEGUEN', 'Thierry', 'Hommes', '1959-05-31'),
(103, 'DONNART', 'Nolwenn', 'Femmes', '1999-08-18'),
(104, 'CAIGNARD', 'Lisa', 'Femmes', '2007-05-18'),
(105, 'GOURLAY', 'Louise', 'Femmes', '2007-01-04'),
(106, 'ANQUETIN', 'Amélie', 'Femmes', '2001-08-29'),
(107, 'LE COQ', 'Enora', 'Femmes', '2000-07-08'),
(108, 'GROSJEAN', 'Marine ', 'Femmes', '1989-02-02'),
(109, 'LACO', 'Peggy', 'Femmes', '1973-01-29'),
(110, 'CHIRON ', 'Jonathan', 'Hommes', '2001-01-13'),
(111, 'KERAVEC', 'Benoit', 'Hommes', '1974-12-13'),
(112, 'TANGUY', 'Olivier', 'Hommes', '1974-05-03'),
(113, 'OLLIVIER', 'Florian', 'Hommes', '1987-11-11'),
(114, 'QUINIOU', 'Gaetan', 'Hommes', '2001-09-10'),
(115, 'SEVELEDER', 'Virginie', 'Femmes', '1975-03-08'),
(116, 'PERSON', 'Erine', 'Femmes', '2004-03-13'),
(117, 'TOULHOAT', 'Marie', 'Femmes', '1967-11-11'),
(118, 'RENEVOT', 'Mael', 'Hommes', '1997-05-02'),
(119, 'QUEMENER', 'Tanguy', 'Hommes', '2002-04-22'),
(120, 'LESPAGNOL', 'Thomas', 'Hommes', '1998-01-18'),
(121, 'VALLLEE', 'Thyphaine', 'Femmes', '1991-05-30'),
(122, 'VALLEE', 'Typhaine', 'Femmes', '1991-05-30'),
(123, 'BERTHEVAS', 'Servanne', 'Femmes', '1997-12-29'),
(124, 'LE GOFF', 'Maëla', 'Femmes', '1997-11-22'),
(125, 'SIDOIT', 'Maxime', 'Hommes', '1999-07-27'),
(126, 'LE ROUX ', 'Michel', 'Hommes', '1966-09-29'),
(127, 'BINIOU', 'Williams', 'Hommes', '1991-04-05'),
(128, 'BASTARD', 'Jacques', 'Hommes', '1959-04-10'),
(129, 'L HELGOUARCH LE MOIGNE', 'Robin', 'Hommes', '2008-09-18'),
(130, 'TUAL', 'Hélorie', 'Femmes', '1992-08-20'),
(131, 'CARIOU', 'Gaetan', 'Hommes', '1996-03-20'),
(132, 'RIGAULT', 'Gwen', 'Femmes', '1998-11-06'),
(133, 'HONTEBEYRIE', 'Delphine', 'Femmes', '1989-09-19'),
(134, 'SEZNEC', 'Enora', 'Femmes', '1999-03-21'),
(135, 'GUILLAUME', 'Romane', 'Femmes', '1999-02-14'),
(136, 'JUTTEAU', 'Leonie', 'Femmes', '2002-05-31'),
(137, 'LE LAY', 'Robin', 'Hommes', '1991-12-20'),
(138, 'KERNALEGUEN', 'Damien', 'Hommes', '1990-05-11'),
(139, 'CREQUER', 'Morgan', 'Hommes', '1998-08-11'),
(140, 'BIHAN-POUDEC', 'Emmanuel', 'Hommes', '1969-02-03'),
(141, 'BURGUIN', 'Pauline', 'Femmes', '1984-01-01'),
(142, 'PARISSE', 'Anne', 'Femmes', '1966-06-23'),
(143, 'PERON', 'Sophie', 'Femmes', '1974-07-14'),
(144, 'DESILLE', 'Anne', 'Femmes', '1970-11-05'),
(145, 'BOISTUAUD', 'Laurent', 'Hommes', '1971-04-20');

-- --------------------------------------------------------

--
-- Structure de la table `performances`
--

CREATE TABLE `performances` (
  `id` int(11) NOT NULL,
  `nageur_id` int(11) NOT NULL,
  `epreuve_id` int(11) NOT NULL,
  `categorie_id` int(11) NOT NULL,
  `lieu_id` int(11) NOT NULL,
  `saison` int(11) NOT NULL,
  `temps` varchar(20) NOT NULL,
  `date_perf` varchar(50) DEFAULT NULL,
  `classement` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nom_categorie` (`nom_categorie`);

--
-- Index pour la table `epreuves`
--
ALTER TABLE `epreuves`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nom_epreuve` (`nom_epreuve`);

--
-- Index pour la table `grille_qualifs`
--
ALTER TABLE `grille_qualifs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `grille_qualifs_ibfk_1` (`epreuve_id`),
  ADD KEY `grille_qualifs_ibfk_2` (`categorie_id`);

--
-- Index pour la table `lieux`
--
ALTER TABLE `lieux`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nom_lieu` (`nom_lieu`);

--
-- Index pour la table `nageurs`
--
ALTER TABLE `nageurs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_nageur` (`nom`,`prenom`);

--
-- Index pour la table `performances`
--
ALTER TABLE `performances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_perf` (`nageur_id`,`epreuve_id`,`date_perf`,`temps`),
  ADD KEY `epreuve_id` (`epreuve_id`),
  ADD KEY `categorie_id` (`categorie_id`),
  ADD KEY `lieu_id` (`lieu_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2421;

--
-- AUTO_INCREMENT pour la table `epreuves`
--
ALTER TABLE `epreuves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=141;

--
-- AUTO_INCREMENT pour la table `grille_qualifs`
--
ALTER TABLE `grille_qualifs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT pour la table `lieux`
--
ALTER TABLE `lieux`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2550;

--
-- AUTO_INCREMENT pour la table `nageurs`
--
ALTER TABLE `nageurs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;

--
-- AUTO_INCREMENT pour la table `performances`
--
ALTER TABLE `performances`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `grille_qualifs`
--
ALTER TABLE `grille_qualifs`
  ADD CONSTRAINT `grille_qualifs_ibfk_1` FOREIGN KEY (`epreuve_id`) REFERENCES `epreuves` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `grille_qualifs_ibfk_2` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `performances`
--
ALTER TABLE `performances`
  ADD CONSTRAINT `performances_ibfk_1` FOREIGN KEY (`nageur_id`) REFERENCES `nageurs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `performances_ibfk_2` FOREIGN KEY (`epreuve_id`) REFERENCES `epreuves` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `performances_ibfk_3` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `performances_ibfk_4` FOREIGN KEY (`lieu_id`) REFERENCES `lieux` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
